/**********************************************
 Workshop #
 Course:        APD545 - SU25
 Last Name:     Phan
 First Name:    Khiet Van
 ID:            147072235
 Section:       NAA
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Khiet Van Phan
 Date:          May 25th,2025
 **********************************************/

package khietvan.models;

import khietvan.interfaces.IDeviceMaintainable;

public class SmartTV extends EntertainmentDevices implements IDeviceMaintainable {

    public SmartTV(String name, double cost, String functionType, String functionality) {
        super(name, cost, functionType, functionality);
    }

    public SmartTV(double cost){
        this("SmartTV",cost,"Visual entertainment","Streaming and media viewing");
    }

    @Override
    public String operatingInstructions(){
        return "By using remote control";
    }

    public String maintenanceInstructions(){
        return "Update firmware, clean screen";
    }
}
